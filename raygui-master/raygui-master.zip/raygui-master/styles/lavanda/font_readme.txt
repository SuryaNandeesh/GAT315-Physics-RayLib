Cartridge by jeti: A decorative, Art Nouveau-inspired font with a dainty, fantastical hand-lettered feel.

You are free to use this font for personal or commercial projects, all I ask is that you include credit.

Licensed under CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
More info: https://fontenddev.com/fonts/cartridge/
